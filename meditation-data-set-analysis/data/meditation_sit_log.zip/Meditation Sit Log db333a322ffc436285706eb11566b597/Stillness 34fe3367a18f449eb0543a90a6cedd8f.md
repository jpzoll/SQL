# Stillness

Date & Time ⏰: September 8, 2022 11:54 AM
Guided: Partially
Length (Minutes): 38
Tags: Stillness

# Practice

- 16 min guided stillness
- 22 min stillness

# Content

- mind attracting to everything and picking it up
- Some moments of resting
- Some moments immediately thinking again
- Lots of HEAT
- Hardness
- Mind wandered more as physical discomfort arose

# Focus / Action Step

- see through what truly creates the conditions for rested mind in genuine stillness
- Try this again tomorrow