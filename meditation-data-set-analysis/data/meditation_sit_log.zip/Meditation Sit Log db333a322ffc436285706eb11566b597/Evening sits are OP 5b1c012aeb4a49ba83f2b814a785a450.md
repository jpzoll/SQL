# Evening sits are OP

Date & Time ⏰: October 19, 2022 7:20 PM
Length (Minutes): 13
Tags: Body / Grounding Awareness

# Practice

# Content

- thoughts of wonder about the beautiful thing happening “in my life”
- Clinging, but relaxing and ENJOYING the beautiful thoughts
- Seeing the universe are infinitely large, and clinging creates suffering because it cannot be conceptualized nor abstracted

# Focus / Action Step