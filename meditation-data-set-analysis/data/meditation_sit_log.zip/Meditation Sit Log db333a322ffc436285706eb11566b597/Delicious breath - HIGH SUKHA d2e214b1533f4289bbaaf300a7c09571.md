# Delicious breath - HIGH SUKHA

Date & Time ⏰: September 17, 2022 1:27 PM
Length (Minutes): 30
Tags: Doing Nothing, Stillness

# Practice

- do nothing
- Stillness via natural relaxation

# Content

- stronger intention and instructions next time
- Breath is soooo pleasurable. This is amazing and powerful
- Sitting in pain is blissful freedom

# Focus / Action Step

- stillness with stronger instructions / intention OR
- Mindfulness of breathing with this jhana