# Thinking is cool air, beautiful tears

Date & Time ⏰: January 3, 2023 9:13 AM
Guided: Yes
Length (Minutes): 15
Tags: Wim Hoff