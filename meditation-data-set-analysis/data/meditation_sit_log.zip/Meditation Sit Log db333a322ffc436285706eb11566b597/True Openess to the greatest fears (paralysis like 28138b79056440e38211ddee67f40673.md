# True Openess to the greatest fears (paralysis like)

Date & Time ⏰: July 14, 2021 7:48 PM
Tags: Stillness

- Laid down on the ground and contemplated greatest fears coming true
- Pictured it
- Felt terror in the body
    - Chest
    - stomach
- Treated it like an old enemy turned friend
    - Aang and Zuko