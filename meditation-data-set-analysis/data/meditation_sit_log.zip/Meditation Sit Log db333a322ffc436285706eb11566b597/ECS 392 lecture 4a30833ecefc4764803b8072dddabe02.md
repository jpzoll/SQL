# ECS 392 lecture

Date & Time ⏰: September 8, 2021 10:20 AM

- Relaxing focus on listening/focusing
- No guilt for the past

# Focus

- Focus on hardness in the throat. The energy built up there
- Allow breathing to be as it is, even if slow or fast
- Pick one certain instruction and remember to **stick with it**
- While walking
    - Movements of attention while immersed into the Now