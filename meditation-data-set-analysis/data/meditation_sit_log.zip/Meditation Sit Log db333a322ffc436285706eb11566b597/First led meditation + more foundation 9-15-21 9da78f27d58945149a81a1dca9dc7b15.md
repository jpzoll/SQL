# First led meditation + more foundation 9-15-21

Date & Time ⏰: September 15, 2021 1:09 PM

- Caffeine increased energy in thinking mind
- Noticed hardness when attention was placed on meditation object. Relaxed tension created the conditions for less thinking while still maintaining concentration
- Periods of remembering increased as the session progressed

# Focus

- Continue concentration practice and build up mindfulness with RELAXED effort
- Continue mindfulness in daily life
    - Lecture
    - Working