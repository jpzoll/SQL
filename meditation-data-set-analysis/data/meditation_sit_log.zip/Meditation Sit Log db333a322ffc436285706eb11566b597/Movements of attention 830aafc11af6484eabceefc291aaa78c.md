# Movements of attention

Date & Time ⏰: September 1, 2021 3:53 PM

- Watch midl 3 again. There is some tension in the breathing that my be caused by incorrect application of instruction
- Remember to stick to intention.
- Noticed movements of attention to
    - Music
    - 2 hour future