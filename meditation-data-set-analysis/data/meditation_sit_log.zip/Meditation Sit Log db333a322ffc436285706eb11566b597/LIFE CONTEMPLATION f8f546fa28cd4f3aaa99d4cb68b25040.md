# LIFE CONTEMPLATION

Date & Time ⏰: November 3, 2022 7:47 PM
Length (Minutes): 63
Tags: Contemplation

# Practice

# Content

- sacrifice
- Highest value is fearlessness
    - Improv
    - Public speaking
    - Game
    - Etc
- Different timeline explorations
    - Me in NYC going on the train living great with people
    - Being in the office
    - Being on LI
- ***Psychedelic visualizations***
- highest values
    - Being in discord group leading people and being so honest with people
    - Leading people
    - Transforming peoples consicousness on a massive scale and transforming their lives in incredible ways
    - Making lots of money

# Focus / Action Step

start a business

start a business

start a business

- apply for cuse rotational programs - best scenario is I quit school while working here enjoying vibrant life
- Look at apartments in NYC
- REad e myth and start business tm