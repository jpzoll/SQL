# Resting the source 12-21-21

Date & Time ⏰: December 21, 2021 11:29 PM

# Practice

- Shamatha

# Content

- noticed the “doer” wandering around (attention) and seeing is relax and I let it go it’s thing
- Positive reactions to remembering
- Soft effort on object

# Focus / Action Step

- stillness