# It’s time to watch the rabbit hole

Date & Time ⏰: October 20, 2022 11:45 AM
Length (Minutes): 25
Tags: Thoughts / Attention Wandering

# Practice

- watching attention wander

# Content

- mind only sees what it’s biased towards in the moment. It completely forgets the intention
- It forgets because the intention was weak
- It remembers the when the PHYSICAL ELEMENTAL QUALITIES are set as an intention to remember, rather than semi vague “practicing body awareness”

# Focus / Action Step

- watch attention wander again. Deeply understand why it does.
- Understand how the mind seizes wandering permanently. Is that possible? Is that necessary?