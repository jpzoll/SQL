# Breathing Well

Date & Time ⏰: September 27, 2022 11:47 AM
Length (Minutes): 25
Tags: Mindfulness of Breathing

# Practice

# Content

- Following the breath well — wow, it’s actually getting easier!!!!!
- KEYS
    - Gathering the entire ‘committee’ (every part of the mind) focused on breathing (Intention is strong)
    - Enjoying the relaxing breath
    - Counting at the out breath
    - Following the entire breath from beginning to end

# Focus / Action Step

- It is once gain time to train Metta - wonderful Metta
- Thank you for Metta
- Breath with Metta
- Gather the committee for Metta just like the breathing
- Contemplate Metta