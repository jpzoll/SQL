# Workout sit

Date & Time ⏰: January 13, 2023 6:13 PM
Length (Minutes): 49
Tags: Mindfulness of Breathing, Shadow / Trauma

# Practice

- feeling trauma in the body with full awareness, just understanding it’s energy, what it’s doing, what it truly is

# Content

- really, truly, up the ante on effort. Go all in on the breath developing rock solid concentration, and allow for the right time to drop all effort abiding in maximum access concentration
- Effort waned off at times. Allow true effort

# Focus / Action Step

- mindfulness of breathing with full force counting
- Develop effortless concentration on breath m