# REVITALIZATION

Date & Time ⏰: November 29, 2022 11:13 PM
Length (Minutes): 13
Tags: Wim Hoff

I feel a great revitalization in practice. I haven’t stopped sitting, but the quality and intention of my sits have not been at their highest in recent times.

Last week, I faced some intense suffering with a family related matter and it has me extremely driven for freedom from suffering and realizing True happiness, not something I have felt this potent in a long time. I also watched the Frank Yang Guru Viking interview and hearing his path is very inspiring. I know enlightenment isn’t something to chase, but this firm confidence in developing holistic understanding of the path feels strong and I am glad to feel it.

Plan

- gradually bump up to minimum 1 hour of sitting a day
- Do more reading on other teachers and practices. Explore and try something new
- Clear iPhone storage and start recording checkins on path insights

# Intriguing Feats

- Sitting 1 hour a day for 30-60 days, feeling potent changes in Direct Experience; in the body, mind, body-mind…
- Sitting 1 hour a day then 30 minutes in evening for 30-60 days
- Going to Goenka Retreat for 3 days