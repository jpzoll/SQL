# Pieces of the puzzle

Date & Time ⏰: January 18, 2023 7:36 PM
Length (Minutes): 34
Tags: Doing Nothing, Shadow / Trauma

# Practice

# Content

Beliefs and shadow are intertwined 

the pieces

- fear of peers excelling more than me due to entitlement
- Fear of things not being right
- Fear of fucking my life up, being ducked after having a perfect track record
- Admitting I don’t believe in myself to pull this off opens the door

Wow, so this is what is really true 

# Focus / Action Step

- stillness
- Meditation on this again, it contemplation
- Don’t think,