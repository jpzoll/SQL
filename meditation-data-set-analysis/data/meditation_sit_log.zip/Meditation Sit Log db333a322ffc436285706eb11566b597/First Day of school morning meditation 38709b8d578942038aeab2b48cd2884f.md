# First Day of school morning meditation

Date & Time ⏰: August 30, 2021 8:04 AM

# What happened?

Something *super* weird happened with my yawning during the meditation sit that is still going on as I am typing this out. I am yawning a lot, but there is a lot of buildup towards it. In the beginning of the meditation, there was *many* points where the buildup was so long that I didn't actually yawn and get the pleasurable sensations that yawns usually come with.

This created a LOT of fear initially. However, this ended up being an incredibly valuable meditation object that lubricated the illusory sense of control, leading to acceptance of the present moment. It culminated to the acceptance that some of the yawns may be blue balled and there simply will be fear, but it's not personal.

- Retraining breathing patterns
- Stillness meditation

# Focus

- Be curious about the yawning
    - Energy release? Lack of sleep? Morning stuff? Some random event that will simply pass away?
- Relax the urges to "do" anything
    - MIDL 25/52 from today to Saturday or Sunday
- Mindfulness in daily life
    - Bus
    - New classroom
    - MT Bank
    - Returning home