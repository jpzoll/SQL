# Focusing on dullness 11/3/21

Date & Time ⏰: November 3, 2021 8:12 PM

# Practice

- Samantha
    - Open awareness → body → ~~breath~~
    - 

# Content

- Didn’t make it to breath (naturally allowed)

# Focus / Action Step

- Remember intention to focus on breath. Clarify subtitle sensations