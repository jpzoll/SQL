# Mastery king term

Date & Time ⏰: November 25, 2022 12:46 AM
Length (Minutes): 19
Tags: Body / Grounding Awareness

# Practice

# Content

- mastery and incredible, valuable things develop over time. For that reason, next intention is 30+ minutes is sticking with the breath. I see how mastery arises with normalized samadhi, effortless resting of attention on the breath. Effortless meta cognitive introspective AND extrospective awareness

# Focus / Action Step

- 25+ min mindfulness of breathing king term development