# WHAT IS LONELINESS?

Date & Time ⏰: January 14, 2023 5:46 PM
Length (Minutes): 52
Tags: Contemplation, Mindfulness of Breathing

# Practice

# Content

- reference memory-somatic experience of a thing you are contemplating
- Ease and restfulness arose during contemplating

What is loneliness?

- a feeling in the stomach and chest of yearning, craving to be with people, and even more at the core CONNECTING with people
- It is also, on the other side of this coin, a FEAR OF BEING IN A STATE OF OSTRACIZATION FROM SOCIETY. I would say “fear of being ostracized”, but it feels more accurate to describe it as a fear of a separate, conceptual state that implies no human connection

How is this (loneliness) transcended?

- Gratitude. Tearing up, filled up heart gratitude from remembering who is already in your life that you are grateful that they’re there
- Create your own vehicles of consciousness and smash them into the norms. Such as your own social groups that collide with SU

Anything else?

- the desire for connection is also linked to the DESIRE TO BE SEEN AS GREAT / ADMIRED.

 

# Focus / Action Step

Reflection on those contemplative arisings

- breath in the body and FEEL what is there
- Feel it, and realize you do not have to bend to its will. You are a being capable of creating new consciousness objects which re-write the narrative