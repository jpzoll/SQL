# Real breathing

Date & Time ⏰: November 23, 2022 3:47 PM
Length (Minutes): 24
Tags: Mindfulness of Breathing

# Practice

# Content

- genuine, free of control, breathing is the best. I used to want to control the breath and felt sad that teachers said to just watch it. This sit, it felt so joyful to let it be and observe the physical sensations
- Intention became more clear and remembered throughout sit

# Focus / Action Step

- same practice. Count count