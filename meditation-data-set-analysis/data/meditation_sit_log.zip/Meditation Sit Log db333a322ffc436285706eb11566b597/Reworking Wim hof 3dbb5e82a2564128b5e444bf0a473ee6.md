# Reworking Wim hof

Date & Time ⏰: January 4, 2023 9:22 AM
Guided: Yes
Length (Minutes): 15
Tags: Wim Hoff

Lots of thinking because there is no intention. I am simply doing this for the body, but it is more enjoyable to rest in the bliss of no thought, no mind