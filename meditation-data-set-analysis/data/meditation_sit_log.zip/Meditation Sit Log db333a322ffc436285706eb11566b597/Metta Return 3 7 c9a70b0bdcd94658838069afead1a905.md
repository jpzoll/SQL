# Metta Return 3/7

Date & Time ⏰: October 6, 2022 12:55 PM
Length (Minutes): 47
Tags: Body / Grounding Awareness, Metta

# Practice

# Content

- mind was incredibly muddy and high energy from doing a lot in daily life (college classes, clubs, lots of people, commitments). This shows the importance of integrating daily life
- Caffeine buzz energy
- Relaxing body relaxes mind on our breath
- Metta genuinely generated more than previously seen. Metta for all, myself, friends, family, and acquaintances. Felt in the heart
- It is imperative to remember where I am, the sense field periodically throughout the day. Where is there pulling? Clinging?

# Focus / Action Step

- metta again
- Periodically check in throughout the dqy
    - First class
    - Before boxing
    - Late evening