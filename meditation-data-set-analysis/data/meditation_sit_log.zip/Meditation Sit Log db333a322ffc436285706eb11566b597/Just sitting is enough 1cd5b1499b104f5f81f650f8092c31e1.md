# Just sitting is enough

Date & Time ⏰: November 25, 2022 3:54 PM
Length (Minutes): 18
Tags: Body / Grounding Awareness

# Practice

# Content

- beliefs thoughts about how the way I’m sitting “isn’t right”. All that is stupid noise to be aware of
- Take this all into daily life
- Sleepy
- 

# Focus / Action Step

- stick with intentions
- Long sit