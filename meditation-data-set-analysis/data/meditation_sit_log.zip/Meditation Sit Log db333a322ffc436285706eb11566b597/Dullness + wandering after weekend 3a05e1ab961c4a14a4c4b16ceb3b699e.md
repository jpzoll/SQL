# Dullness + wandering after weekend

Date & Time ⏰: August 2, 2021 12:14 PM
Tags: MIDL 06/52, Mindfulness of Breathing, Stillness

# What happened?

- Dullness
- Wandering
- Slightly more control of the breathe
- However, there were several points where I softened into the control and gave it up
- Less aversion in general, as I am grateful for the lessons suffering teaches me

# Focus

- Go to bed on time tonight → Energy during tomorrow's sits
- If I have energy and there is still control by the end of this week's sit, then I will go back to training stillness and softening