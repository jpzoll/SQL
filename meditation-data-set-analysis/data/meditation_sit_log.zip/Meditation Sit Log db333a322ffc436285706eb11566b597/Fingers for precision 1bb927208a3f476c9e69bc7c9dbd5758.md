# Fingers for precision

Date & Time ⏰: October 10, 2022 11:50 AM
Length (Minutes): 7
Tags: Fingers Touching