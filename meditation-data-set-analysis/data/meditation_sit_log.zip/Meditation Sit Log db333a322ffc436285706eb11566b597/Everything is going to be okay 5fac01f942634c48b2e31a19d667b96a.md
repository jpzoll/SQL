# Everything is going to be okay

Date & Time ⏰: January 18, 2023 1:57 PM
Length (Minutes): 13
Tags: Stillness

# Practice

# Content

- I feel high energy pull emerging from the body
- Relaxed body and mjnf
- Allowed mind to wander

# Focus / Action Step

- stillness
- Contemplate sleep
- Contemplate choice