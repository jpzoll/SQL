# hendricks remembering 11/10/21

Date & Time ⏰: November 10, 2021 11:56 AM

# Practice

- Shamatha w the body

# Content

- Increased periods of simply remembering
- When lots of thoughts or agitation arose, I allowed the mind to get sucked within them, counterintuitively making periods of continuous mindfulness easier\
- Not trying to do anything. Just remembering the experience of just being here
- Resting attention on sensations, *not* on a conceptual mapping (aka a THOUGHT) towards/about the sensation(s)

# Focus / Action Step

- Continue to increase remembering. Do the same thing
- Stillness feels right possible. We will see