# Sleepy but alert 12-18-21

Date & Time ⏰: December 18, 2021 4:32 PM

# Practice

- Shamatha wide
- Shamatha w body
- Shamatha w bodily breath sensations

# Content

- Returning to remembering
- Noticing thought wondering “if this is being done right”. It’s just another thought that can be let go of

# Focus / Action Step

- Another long session like this
- Pay attention to breath. I’m trolled diaphragmatic breathing is amazing  np v