# Relax in the coolness

Date & Time ⏰: December 26, 2022 3:12 PM
Length (Minutes): 14
Tags: Body / Grounding Awareness