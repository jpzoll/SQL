# Pain is no problem

Date & Time ⏰: January 12, 2022 3:20 PM

# Practice

- wide awareness
- Shamatha w abdomen
- Short body scan bottom up style

# Content

- tense parts of the body is no problem
- Emotional pain is no problem

# Focus / Action Step

- MIDL 06/52 later