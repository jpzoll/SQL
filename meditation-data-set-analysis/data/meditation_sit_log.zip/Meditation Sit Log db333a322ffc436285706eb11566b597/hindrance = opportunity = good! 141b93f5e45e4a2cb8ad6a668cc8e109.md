# hindrance = opportunity = good!

Date & Time ⏰: August 6, 2021 5:48 PM

- 10-20 minutes of belly breathing
- 10-20 minutes of shamatha w lungs filling
- 5-15 minutes of Shamatha w lungs filling while sitting up on a chair
    - Increased effort towards the end → longer sustained attention on the lungs filling w air
    - Still some slumping

INSIGHT

- Hindrance arose, and specifically aversion to bad posture and bad concentration → ensuring belly breathing beforehand allowed for easy softening into → aversion is good opportunity to soften → continued softening with this SPECIFIC aversion will make all sitting on chair meditations free of this

FOCUS

- Slumping → continue diligence to back exercises and TRY new ones
- Concentration a bit weak → try increased effort like the last 5 or so minutes of this sit
    - Make distinction between too much effort and too little effort clearer and clearer w trial and error
- Dullness
    - Get more sleep! Focus on sleep!