# Post ds - it’s okay to sense sense blobs

Date & Time ⏰: December 7, 2022 2:29 PM
Length (Minutes): 9
Tags: Body / Grounding Awareness