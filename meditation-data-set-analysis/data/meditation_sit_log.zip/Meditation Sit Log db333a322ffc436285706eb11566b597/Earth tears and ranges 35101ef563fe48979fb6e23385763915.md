# Earth tears and ranges

Date & Time ⏰: September 7, 2021 8:01 AM

# What happened?

- Earth
- Water
- Fire
- Air

# Focus

- Unfocused elements
    - Wetness and dryness range
    - Air range. What is expansion and contraction?
    - Coolness
- Forgetting and range of awareness