# More Courageous Meditation. Not mine

Date & Time ⏰: July 1, 2021 3:34 PM
Length (Minutes): 45
Tags: MIDL 03/52, MIDL Forgiveness

Don't try to recreate experiences. As I engaged in forgiveness meditation today, there was some more deep-seeded memories and emotions that came up. I breathed, I paid attention to what was happening in the body, and I sat as an external observer.

Much of why we suffer is due to the fact that we try to hold onto pleasurable things that occurred in the past. This comes in the form of nostalgia for our childhood or the entenmans cookie you ate 1 minute ago. However, that pain that comes from not getting what you want is the KEY! Look at it, invite it inside the body, love it, and accept it.

In addition, make sure you are talking to yourself correctly. When you notice it for what it is, internally remind yourself that it is simply a craving for something outside of yourself.