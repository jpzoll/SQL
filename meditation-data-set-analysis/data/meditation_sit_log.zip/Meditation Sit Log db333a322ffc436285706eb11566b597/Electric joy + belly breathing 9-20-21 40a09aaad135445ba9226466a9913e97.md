# Electric joy + belly breathing 9-20-21

Date & Time ⏰: September 20, 2021 8:23 AM

- Retraining belly breathing (WITH SLIGHT PERSONAL TWEAKS)
    - First following Stephens instructions
    - Then allowing the breath to operate as is
    - Then making my meditation object any tension in the body, prioritizing tension in muscles/spots breathing passes through. I don’t do anything with the tension. I just wrap my awareness around it and eventually it relaxes
    

focus

- Mind wandering
- Remaining in relaxed breathing throughout the day
- Eventually, metta....