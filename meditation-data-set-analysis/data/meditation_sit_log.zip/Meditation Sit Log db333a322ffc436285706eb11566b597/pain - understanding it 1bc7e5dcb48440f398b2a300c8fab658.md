# pain - understanding it

Date & Time ⏰: December 23, 2022 9:22 PM
Length (Minutes): 45
Tags: Mindfulness of Breathing, Pain

# Practice

- mindfulness of breathing
- pain became so strong, it became the object

# Content

- very hard to concentrate
- TV show made it VERY HARD to focus, which led to anger arising
- sluggishness
- not long restings on breath
- it was not comfortable to be with the breath
- ********it felt natural to rest with the pain and make it the object in focus, as emotionally difficult that was********
- i feel angry because no concentration was developed and the mind kept going out. it feels like a waste of time when the body is not inclined towards the breath. is is burning anger
- **************************************************It is okay. In fact, you WANT to focus on the pain when it becomes strong becaue it allwos youy to see it for what it truly is!**************************************************
- GOOD
    - the one thing was the breath and that was what i focused on, very good, even it was hard to do so
- drop

# Focus / Action Step

- Elminate distractions
- make the body was comfortable as possible to focus on
- if the same thing ever happens, allow long sessions of resting with the pain, seeing it as a stream of impermanent pain that fades away
- drop expectations and enjoy, savory satisfaction