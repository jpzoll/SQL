# Green bird

Date & Time ⏰: October 16, 2021 1:47 PM
Length (Minutes): 65

[Green Bird](https://open.spotify.com/track/1njuTHu8RYBUQ4zOiays0Q?si=ERrDKq1DSKi9mdmgHQh_Jg)

# Practice

- Diaphragmatic breathing
- Stillness meditation
- Gratitude

# Content

- Relaxing at the source. I kept the feelings of relaxation in mind and as the body relaxed, so did thinking
- Insight → With awareness, I was able to see very clearly where suffering has been created for the past day or so. It’s typically when I return from thinking and instead of residing in awareness, I drop into delusion and aversion towards the thinking or whatever action I just engaged in
- Immense gratitude from having this whole day to myself

# Focus / Action Step

- Stillness an gratitude → continue
- Pay attention to how this can bleed into daily life. Believe in moving forward and trust. Don’t be so hard on yourself
- Gratitude is a key for ending worry
-