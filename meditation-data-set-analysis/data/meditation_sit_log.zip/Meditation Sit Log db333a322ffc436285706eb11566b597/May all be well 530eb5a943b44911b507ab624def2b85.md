# May all be well

Date & Time ⏰: January 12, 2023 9:13 AM
Length (Minutes): 12
Tags: Wim Hoff

# Practice

# Content

Regularized body

Fresh body

Solid body

Welll

# Focus / Action Step

mindfulness of breathing samadhi