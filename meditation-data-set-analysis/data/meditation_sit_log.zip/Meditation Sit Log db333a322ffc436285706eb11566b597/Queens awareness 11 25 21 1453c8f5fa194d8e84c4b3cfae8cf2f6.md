# Queens awareness 11/25/21

Date & Time ⏰: November 25, 2021 3:41 PM

# Practice

- Ranged shamatha
    - Fingers, body, open

# Content

- Acceptance of pain arose mid sit
- Noticing thoughts of uncertainty.
- 

# Focus / Action Step

- Stillness