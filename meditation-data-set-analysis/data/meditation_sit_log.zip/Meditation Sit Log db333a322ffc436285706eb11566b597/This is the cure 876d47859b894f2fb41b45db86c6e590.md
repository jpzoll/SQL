# This is the cure

Date & Time ⏰: November 27, 2022 4:55 PM
Guided: Yes
Length (Minutes): 51
Tags: Mantra, Thoughts / Attention Wandering

# Practice

# Content

- the mind is inclining towards victim hood and creating a story that brings justice to Matthew. There is delusion here, so I feel it’s best to find the exquisite balance between taking action and not making a big deal out of things. In presence, you feel no need to be extra
- There is finally SOME resting of the mind and leaving alone the narrative around my family and brother. However, it takes 360 DEGREE GATHERING OF THE MIND COMMITTEE AND FOCUSING ON THE MEDITATION OBJECT
    - Mantra meditation is best for knocking out of thinking mode, and then once that normalizes mindfulness of breathing

# Focus / Action Step

- mantra meditation normalized in MIDL
- Speak to skillful people that help
    - Give wisdom on the situation
    - Who provide emotional support
    - Build a bond
    - Put me on a path of living an amazing life; with great and healthy people in it
- Don’t speak to people for these reasons
    - For attention
    - To pit people against someone
    -