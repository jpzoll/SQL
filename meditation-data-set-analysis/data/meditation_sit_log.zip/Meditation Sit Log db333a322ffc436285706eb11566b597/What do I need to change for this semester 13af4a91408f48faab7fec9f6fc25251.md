# What do I need to change for this semester?

Date & Time ⏰: October 2, 2022 9:47 PM
Length (Minutes): 30
Tags: Contemplation

# Practice

# Content

Ways to make myself take action

1. Imagine David goggins and all his hardships or another inspirational figure looking down in you
2. Meditate before game session and make the intention STRONG, walking in mindfully and walking up to a girl mindfully
3. SA exposure exercise before going into the bar
4. 5-20 minutes visualizing myself having a successful, sexually tense interaction that leads to the 1 lay
5. Write down on my hand the #1 sticking point for the night and keep coming back to that intention

# Focus / Action Step