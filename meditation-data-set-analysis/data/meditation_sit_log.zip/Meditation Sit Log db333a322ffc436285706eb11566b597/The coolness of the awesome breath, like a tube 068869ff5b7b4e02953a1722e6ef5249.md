# The coolness of the awesome breath, like a tube

Date & Time ⏰: December 17, 2022 7:15 PM
Length (Minutes): 34
Tags: Body / Grounding Awareness, Mindfulness of Breathing, Shadow / Trauma