# Calm cleaning

Date & Time ⏰: October 1, 2022 2:17 PM
Length (Minutes): 17
Tags: Body / Grounding Awareness

# Practice

# Content

Body brething

No high valence or stickiness of feeling

Seeing source of mental agitation 

Seeing mud puddles, or imprints, left by entertainment on the mind

# Focus / Action Step

- keep phone away and embrace life
- Concentration mastery or something new like metatarsals