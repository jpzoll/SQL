# Good determination

Date & Time ⏰: November 13, 2022 7:24 PM
Length (Minutes): 11
Tags: Mindfulness of Breathing

# Practice

# Content

- good dead set focus on the breath
- Seeing that the key now is being happy about the mind returning

# Focus / Action Step

- 25+ minute sit developing concentration
- Carry into daily life
- Do what is emotionally difficult