# 1hr metta + breathing 10-15-21

Date & Time ⏰: October 15, 2021 12:37 PM

# Practice

- Diaphragmatic breathing
- Metta
- Gratitude

# Content

- Attention on individuals I was sending metta to
- Forgetting increased a bit during a later portion of the metta sit
- Relaxed energy towards worry-thinking
    - Soften the corresponding tension in the body
- Tools
    - Breathing
    - Acceptance of the present moment
- Stillness and gratitude next...

# Focus / Action Step

- Stillness and gratitude