# A good start to 2023

Date & Time ⏰: January 1, 2023 10:59 PM
Guided: Partially
Length (Minutes): 35
Tags: Mindfulness of Breathing, Wim Hoff