# How is comfort in SS materializing?

Date & Time ⏰: September 7, 2022 10:34 AM
Length (Minutes): 37
Tags: Contemplation

# Practice

- contemplate → “how is comfort in all social situations manifesting now?”

# Content

- not a lot of clear answers today
- Some mind wandering and returning back
- The reality is resting in stream, Truly normalized in it
- Good breathing creates the reality of stream enjoyed
- The mind enjoys the stream
- Being very open
- Mastering playful banter and humor
- Approaching visions

# Focus / Action Step

- Contemplate this 1-2 more times and move on
- Next → normalized resting in stream; stillness enjoyed genuinely by the mind and preferred over wandering in daily life and in sits