# Metta Return 1/7

Date & Time ⏰: October 4, 2022 11:02 AM
Length (Minutes): 40
Tags: Body / Grounding Awareness, Metta

# Practice

# Content

- Metta welling up occasionally, beautiful as always
- Seeing contractions and relaxing, leading to wideness and expansion
- Awareness of metta & thinking metta - different domains
- Selfless giving is done with the motion, not as a pull
- Metta normalizes in being

# Focus / Action Step

- metta again for next 7 days