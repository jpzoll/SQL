# Sleepy but flexible Gratitude

Date & Time ⏰: July 26, 2021 12:30 PM
Length (Minutes): 68
Tags: Gratitude

# What happened?

- Very sleepy, need more rest the night before
- Shifted between states fluidly
    - No guilting or ruminating about mind-wandering. What helped this was centralizing all focus to gratitude practice instead of not forgetting (and simply seeing through the pointlessness of guilting oneself)

# Focus

- Get sleep
- Take Gratitude into daily life
- Take mindfulness into daily life