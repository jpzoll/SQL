# Never forget RELATIONSHIP

Date & Time ⏰: July 14, 2021 1:01 PM
Length (Minutes): 51
Tags: MIDL 39/42, MIDL Metta Loved One, Stillness

- Stillness sitting up
- Some unconscious material bubbled up
- Seeing source
- Good Relationship with posture, some imperfections
- Not doing anything about not doing about not doing about....
- No excessive force
    - Trust in your habitual tendencies that you have trained to be mindful, wholesome, loving kind

### Notes

- This is a little hard to put into words but be aware of the neurotic loop/vortex/clinging that tries to make unneurotic behavior into neurosis
    - Neurotically controlling softening breathing → excessive force
    - Excessive force → Excessive forcing no force 😂
- How do I do (or to phrase it better, *not do*) this?
    - Be in the moment
    - *Periodically* check for excessive force
    - What is the current relationship with the present moment?