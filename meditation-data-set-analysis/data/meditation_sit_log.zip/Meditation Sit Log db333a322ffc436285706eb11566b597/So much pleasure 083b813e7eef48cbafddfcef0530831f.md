# So much pleasure

Date & Time ⏰: September 10, 2021 2:19 PM

- The first sit if today ended with some of the most pleasurable, delicious stillness and presence I have ever experienced in a sit. This feeling is amazing wow

Focus

- Subtle fear of losing the feeling
- Subtle aversion to mindfulness in daily life