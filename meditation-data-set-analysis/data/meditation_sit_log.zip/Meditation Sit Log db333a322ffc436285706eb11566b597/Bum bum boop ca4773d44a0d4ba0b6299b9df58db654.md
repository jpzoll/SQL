# Bum bum boop

Date & Time ⏰: December 30, 2022 4:02 PM
Length (Minutes): 29
Tags: Mindfulness of Breathing

# Practice

# Content

- mind wandeting
- If the body still enough?
- Practice full body relaxation with out breath so mind rests
- However it helps adding in more humph to effort committee

# Focus / Action Step

- mindfulness of breathing again. The vision is crystal clear concentration that sees every microscopic sensation