# Walking + Friday recess

Date & Time ⏰: September 9, 2022 12:59 PM
Length (Minutes): 25
Tags: Stillness, Walking

# Practice

1. Walking
2. Stillness

# Content

integration is so key

it does not matter how much you meditate for, the heart is the quality of it **which then gets integrated + transmuted into daily life**. I saw this as I was sitting in Recess coffee

# Focus / Action Step

- Walk gentle and slow
- See the beauty of stillness
- See the beauty of sitting still, slow
- See the beauty of resting in God
- See the beauty of being Nothing
- See the beauty of Nothing coming out
- See the beauty of No Mind
- See the beauty of No Thought

1. Stillness meditation again, seeing how long stillness can be sustained
2. Periodically check for stillness throughout today
    1. Shift
    2. At the party
    3. In the middle of conversation with people