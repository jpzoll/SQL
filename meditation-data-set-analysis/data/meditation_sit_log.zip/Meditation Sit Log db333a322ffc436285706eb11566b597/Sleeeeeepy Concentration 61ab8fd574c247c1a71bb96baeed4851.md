# Sleeeeeepy Concentration

Date & Time ⏰: August 10, 2021 12:31 PM
Tags: MIDL 03/52, Mindfulness of Breathing

- Retraining Breathing
- Mindfulness of Breathing

# What happened?

- Sleepy during retraining of breathing
- I noticed that **chest breathing had become pretty normalized prior to this sit, as it took long to normalize belly breathing**
- Difficult to focus on the breath

# Focus

- Normalize Belly Breathing
- Longer concentration on the breath with relaxed effort
- For the rest of today
    - Be aware of when I start and end a work session
    - Next sit
        - Belly breathing
        - Anapasati