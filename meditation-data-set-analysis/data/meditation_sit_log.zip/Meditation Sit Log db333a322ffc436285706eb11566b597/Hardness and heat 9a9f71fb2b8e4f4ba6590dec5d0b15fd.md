# Hardness and heat

Date & Time ⏰: September 15, 2022 11:00 AM
Length (Minutes): 47
Tags: Body / Grounding Awareness, Contemplation, Elemental Qualities, Pain

# Practice

- mindfulness of breathing, switched to body and pain once it arose and was very strong

# Content

- strong intention in beginning but then weak after. I feel it’s best to stick to one technique all the the way through and simply change after
- Though : the way to get over the mountain wall quality of SF is sinking into the pain and sitting with it
- Pain is good, break it up into elemental qualities
- LOTS of thinking

# Focus / Action Step

- Realize normalize is-ness and this-ness
- Based on feelings before next sit, either
1. Mindfulness of breathing, sharp concentration
2. Mindfulness of pain and wall