# Thank you for this beautiful contemplation

Date & Time ⏰: October 15, 2022 8:09 PM
Length (Minutes): 32
Tags: Contemplation

# Practice

“What is not working this semester? What is working is this semester?”

# Content

- Late Fear
    - Body fear projected onto future
- Importance Principle
    - Let’s go subconsious! I had a beautiful dream
- Late night craving
- Indecision moments
- Sunken Cost Fallacy for Friends

> ***On the right path, with only a few bottlenecks.***
> 

# Focus / Action Step

- Read more
    - Law of Attraction
    - Facing fear
    - Creating an amazing life from the vastness that reality has to offer
- Fasting
    - Thursday → Friday Fast