# Difficulty Forgiving and Dullness

Date & Time ⏰: July 12, 2021 3:14 PM
Length (Minutes): 49
Tags: MIDL Forgiveness, Stillness

# What happened?

- Retraining breathing for 16 minutes
- MIDL guided forgiveness for 25 minutes
- Stillness for 7 minutes

- It was very impactful to forgive myself (green robe me)
- When forgiving someone I had mild difficulties with, it helped to forgive them first and remember the great things they have done for me

# What was weak?

- Sleepiness and Dullness
    - Get more sleep
    - Sleep clinic
- Mind wandering
- Little stillness even though I set that intention

### Next time...

- Get more sleep
- Set a strong intention to do stillness
- 30 minutes of stillness + 30 minutes of metta

# Learned?

- Not attaching to identification *with **either good or bad → NOT RESISTING CHANGE!!!!!!!***