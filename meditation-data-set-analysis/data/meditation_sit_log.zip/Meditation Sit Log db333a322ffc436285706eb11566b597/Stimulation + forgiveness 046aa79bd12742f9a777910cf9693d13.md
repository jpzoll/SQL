# Stimulation + forgiveness

Date & Time ⏰: November 23, 2021 4:10 PM

# Practice

- Wide awareness (Shamatha w everything)
- Shamatha w body
- Shamatha w touch of fingers

# Content

- Accepting and befriending of emotions w negative vedana
- Continued remembering
- Forgiveness
    - Reaching into repressed feelings of resentment and being honest with them. They transmuted into love as I forgave this person. I am very thankful for this experience

# Focus / Action Step

- Daily life
    - I have a healthy relationship with my phone and stimulation
    - No phone when I wake up tomorrow