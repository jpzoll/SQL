# Here is good 11-26-21

Date & Time ⏰: November 26, 2021 3:29 PM

# Practice

- Ranged shamatha

# Content

- Decent periods of remembering with wide awareness
- Little shorter with body
- Not enough sample size of time for fingers touching

# Focus / Action Step

- I remembered that right now is what matters, and how easy it is to get caught up in the past or future
- Consciously use phone, feel how much better it is to be present without the need for stimulation
- Concentration more