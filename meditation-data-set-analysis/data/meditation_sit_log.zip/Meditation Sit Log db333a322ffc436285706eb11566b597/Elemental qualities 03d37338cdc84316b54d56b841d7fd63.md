# Elemental qualities

Date & Time ⏰: September 4, 2021 2:44 PM

- Awareness of Elemental qualities broke down duality between them as one
    - Finding softness in hardness
    - Finding wetness around and within dryness
    - Noticing the change of elemental qualities
    - Movement = change of of elemental qualities
- Foundational awareness was strong
    
    

focus

- Train elemental qualities for 4-7 days (Wed→Fri/Sat)
- Mindfulness while working
-