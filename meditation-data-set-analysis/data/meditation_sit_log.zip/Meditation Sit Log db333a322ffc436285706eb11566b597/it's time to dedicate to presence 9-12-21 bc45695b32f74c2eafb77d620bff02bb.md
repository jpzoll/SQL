# it's time to dedicate to presence 9-12-21

Date & Time ⏰: September 12, 2021 2:15 PM

# What happened?

- Body awareness
    - Contact barrier/line between body and the floor
    - Heaviness of the body
    - Body itself
- Relaxing the mind when I remember

# Focus

- Remembering is weak at the moment.
- There is a lot of things I can work on, such as stillness. However, I will allow myself to be wrong an try out working on my mindfulness
- Treat meal prep like a meditation
- Be present while working
- Body awareness until Wednesday-ish or when mindfulness is stronger