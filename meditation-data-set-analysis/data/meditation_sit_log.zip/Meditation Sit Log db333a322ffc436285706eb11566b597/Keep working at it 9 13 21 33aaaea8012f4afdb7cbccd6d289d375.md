# Keep working at it 9/13/21

Date & Time ⏰: September 13, 2021 7:58 AM

- Midl foundation w body

# Strong

- Relaxed attention on the meditation object (body)

# Weak (Focus)

- Forgetting (keep at it w relaxed effort)
- Move onto breathing?

- Drop mechanical aspects of midl breathing and take MIDL approach (or not. It’s important there’s no control of the breathing)