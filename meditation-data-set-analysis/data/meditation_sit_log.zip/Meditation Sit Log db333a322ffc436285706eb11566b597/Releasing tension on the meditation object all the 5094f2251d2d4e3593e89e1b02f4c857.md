# Releasing tension on the meditation object all the time → The key???

Date & Time ⏰: July 23, 2021 2:45 PM

- I thought during my meditation sit today that if I always release effort on the meditation object, it will lead to more progress. The reasons I say this are as follows:
    - Stephen Procter mentioned that effort is really only slightly above sleep.
    - TMI Stage 4 mentions that at this point in the practice, it is time to let go of trying to stay on the breath
    - Relaxed effort is more reflective of daily life experience