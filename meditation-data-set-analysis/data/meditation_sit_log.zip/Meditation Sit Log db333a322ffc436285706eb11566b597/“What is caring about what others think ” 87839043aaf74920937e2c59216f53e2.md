# “What is caring about what others think?”

Date & Time ⏰: September 6, 2022 9:58 AM
Length (Minutes): 40
Tags: Contemplation

# Practice

- contemplate
    - What is caring about what others think?
    - What are unhealthy levels to it?
    - What are healthy levels to it?
    - How does unhealthy levels to it end?

# Content

- when contemplating what it is and unhealthy levels, thoughts of people in my life arose. Thoughts about doing a certain action that pleases or possibly displeases them, looking cool, etc. it felt Devoid in the heart
- When contemplating healthy levels / how it ends, thoughts of creation, doing activities that I deeply am passionate about, etc. arose

It ends when energy is put towards creative activities that are enjoyable for me personally

Tend to the wounds. Cradle them, love them, kiss them, be there for them and allow them to heal with so much Love.

Hatred is root of caring too much. Love heals and creates strong internal environment that gives selflessly

# Focus / Action Step

- contemplate this more. How does it end?
- Contemplate giving vs. sucking/taking. See it in daily life and relax relax relax