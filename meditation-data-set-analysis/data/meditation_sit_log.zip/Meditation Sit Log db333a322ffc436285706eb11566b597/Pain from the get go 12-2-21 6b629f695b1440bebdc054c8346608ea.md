# Pain from the get go 12-2-21

Date & Time ⏰: December 2, 2021 3:29 PM

# Practice

- Shamatha w body
- Meditation object turning to pain and physical discomfort when it arises strongly

# Content

- This was manifested. I have a healthy relationship with pain and this is proof of it. I can feel the pierced vulnerability. LOVE
- Area around chest became an medium sized MO
- Remembering increased
- Make more of a Diligent intention

# Focus / Action Step

- Concentration or stillness