# Wandering 9-15-21

Date & Time ⏰: September 16, 2021 1:14 PM

- Complete relaxation while laying down
- Working with remembering
- Remembering weaker than expected

# Focus

- Intention to keep with the meditation object with absolute diligence