# Touch of thumbs 11-8-21

Date & Time ⏰: November 8, 2021 10:56 PM

# Practice

- Grounding awareness
- Shamatha w thumbs

# Content

- Increasing concentration
- Noticing getting caught up within thinking and returning with applied attention to touch of thumbs
- Dullness arose almost immediately

# Focus / Action Step

- Shamatah with body and/or thunbs
- Increased concentration by next so meeting
- Read up on aspect do pracrice
-