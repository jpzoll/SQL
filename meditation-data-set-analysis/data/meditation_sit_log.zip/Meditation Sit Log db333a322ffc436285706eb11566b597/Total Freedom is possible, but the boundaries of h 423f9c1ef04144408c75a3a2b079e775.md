# Total Freedom is possible, but the boundaries of human life within society must be respected

Date & Time ⏰: July 28, 2021 2:54 PM

- Example: I could be completely non-attached to the relationship of someone to who I have a responsibility towards, and I *would be free*. However, that will create conditions that I simply deem as pointless. Obviously, these conditions come from attachment and fear, but at some of the absolute deepest level (the Ultimate being death).
    
    Sure, you can lose sanity and be fully "yourself", but that would mean **giving meaning to meaninglessness,** so why not exude loving-kindness?
    

 

---

# What happened?

- Belly breathing was automatic from the start
- Uncontrolled mindfulness of breathing
    - A little more controlled as the meditation progressed

After working exclusively on natural belly-breathing, stillness, and metta (MIDL framework) ever since the beginning of June, I started with mindfulness of breathing today and wow, the habitual control has been released to a great extent. I was so stuck within TMI doing mindfulness of breathing for about 4 months last year, and switching to MIDL really helped.

Softening in daily life, and especially to difficult conditioned responses with Vedana, has been tremendously impactful. 

If any of you have ever considered speaking with Procter, I *highly encourage it*. That meeting I had with him back at the end of may really set me on this path to this progress I am sharing with you now. I am confident and non-complacent the practice moving forward. I intend on centralizing focus to mindfulness of *uncontrolled* breathing and investigation. I also am focusing on dullness, as that is posing some obstacles. Keep moving forward friends 

# Focus

- How do I investigate?
- How do I overcome dullness?
- I BELIEVE the breath with be uncontrolled and natural