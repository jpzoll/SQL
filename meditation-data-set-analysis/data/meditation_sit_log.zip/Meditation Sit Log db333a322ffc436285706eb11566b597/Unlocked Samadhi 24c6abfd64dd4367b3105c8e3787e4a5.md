# Unlocked Samadhi

Date & Time ⏰: January 7, 2023 11:23 AM
Length (Minutes): 29
Tags: Mindfulness of Breathing

# Practice

# Content

- genuine, relaxing samadhi arose with unification of attention
- qualities ::> coolness in head and body, fading away of aversion, satisfaction of resting with breath
- At the head, attention turned towards underlying fear of “being late” and “needing” to answer text from friend
- Insight ::> It’s not about being in the mode of thinking, just keep returning to the breath with the intention of staying AND ENJOYING THE BREATH. Relax the body if you’re trying too hard, that’s how samadhi arose for me

# Focus / Action Step

- Mindfulness of breathing