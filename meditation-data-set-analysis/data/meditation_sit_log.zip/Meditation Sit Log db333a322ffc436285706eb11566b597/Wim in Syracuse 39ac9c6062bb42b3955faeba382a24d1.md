# Wim in Syracuse

Date & Time ⏰: January 11, 2023 9:19 AM
Guided: Yes
Length (Minutes): 15
Tags: Wim Hoff

# Practice

# Content

- knowing rising and passing away
- Knowing here is all that matters, mindfulness materializes naturaly and on its own
- Thoughts are okay. Just objects passing. Clouds

# Focus / Action Step

- bump up intention