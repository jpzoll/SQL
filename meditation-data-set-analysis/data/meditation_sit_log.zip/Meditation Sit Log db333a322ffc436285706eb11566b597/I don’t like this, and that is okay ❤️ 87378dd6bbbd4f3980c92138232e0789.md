# I don’t like this, and that is okay ❤️

Date & Time ⏰: December 27, 2022 7:39 PM
Guided: Partially
Length (Minutes): 39
Tags: MIDL 03/52

# Practice

- Midl softening guided
- Following the breath
- Relaxing the body and mind

# Content

- mind wandered a LOT
- this is something I have noticed for years. There had never been a point where the mind completely settles in presence. How does the mind stop thinking? How does the mind stop thinking naturally in MY EXPERIENCE. In my personal experience, how does that truly arise?

# Focus / Action Step