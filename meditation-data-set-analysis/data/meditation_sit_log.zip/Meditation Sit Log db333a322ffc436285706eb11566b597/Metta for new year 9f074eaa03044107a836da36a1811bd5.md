# Metta for new year

Date & Time ⏰: December 31, 2022 11:10 AM
Guided: Partially
Length (Minutes): 35
Tags: Metta

# Practice

# Content

- feel energy pull
- Relax with out breath
- Coolness is here
- All there is is now hereness
- 

# Focus / Action Step