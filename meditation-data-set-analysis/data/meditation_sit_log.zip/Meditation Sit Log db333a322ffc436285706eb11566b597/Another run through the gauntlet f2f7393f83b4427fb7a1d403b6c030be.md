# Another run through the gauntlet

Date & Time ⏰: September 1, 2021 8:08 AM

- Feelings of loss
- Stillness in the body
- Slowing down of thinking and returning to relaxed source

# Focus

- "Where is my breathing?" → ask myself this question throughout the day
- Mindfulness throughout the day
    - Bus
    - Listening to lecture
    - Work
- I'm not sure what is truly causing the suffering, but I will figure it out. I think part of everything is the new change in scenery being back at college, but I can't say for certain. If I continue moving forward and not much changes I suspect it is due to softening not actually being done correctly