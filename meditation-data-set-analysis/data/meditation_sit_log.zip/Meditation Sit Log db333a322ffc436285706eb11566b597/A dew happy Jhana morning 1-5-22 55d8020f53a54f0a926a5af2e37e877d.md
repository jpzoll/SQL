# A dew happy Jhana morning 1-5-22

Date & Time ⏰: January 5, 2022 11:20 AM

# Practice

- softening into stillness

# Content

- deep soft belly breathing and relaxing the body from the top down led to a STILL MIND
- There was however:
    - Mind wandering
    - Dullness
- One big lesson → PRACTICE makes developed skills in the mind. Sure, I struggled before, but since I kept w doing the same exercise I naturally learned stillness
- Relaxed → no feeding ( seems like a variation for relaxed at source). I am grateful to have trained a still mind

# Focus / Action Step

- AGAIN
- Later on Shamatha w counting