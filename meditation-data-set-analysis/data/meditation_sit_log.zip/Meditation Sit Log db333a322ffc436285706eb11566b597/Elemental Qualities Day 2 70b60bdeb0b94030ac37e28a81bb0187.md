# Elemental Qualities Day 2

Date & Time ⏰: September 5, 2021 8:54 PM

- I set the intention right after my morning meditation sit to remember the elemental qualities in my direct experience throughout the day. This seemed to help as I remembered more and more
- Earth very noticeable
- Movement noticeable when breathing
- Earth in the face
-