# The amazing Spider-Man  2 - gradual heroic song

Date & Time ⏰: December 29, 2022 3:42 PM
Length (Minutes): 36
Tags: Mindfulness of Breathing

# Practice

# Content

- lots of forgetting and coming back
- Great content in SEEING THE CONTENTS OF THE MIND SEEING WHAT WAS WANDERED OFF YOO. It felt like feeding, nourishing the mind with genuine understanding
- Shadow work is incredible
- Caffeine creates satisfaction

# Focus / Action Step

- stillness meditation in gym instead of Wim hoff
- Write shadow work understandings
- Mindfulness of breathing 35+ minutes again