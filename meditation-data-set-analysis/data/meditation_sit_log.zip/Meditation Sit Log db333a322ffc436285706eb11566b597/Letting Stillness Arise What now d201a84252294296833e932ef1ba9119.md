# Letting Stillness Arise | What now?

Date & Time ⏰: July 10, 2021 1:07 AM
Length (Minutes): 17

# What happened?

- Relaxed individual parts of the body
- Stillness arose (relaxation from)

What now? I'm sitting with stillness but I don't know what I should do to be honest

# What's weak?

- Stillness in everyday life
    - Complusions
- Wanting "something"
- Insight