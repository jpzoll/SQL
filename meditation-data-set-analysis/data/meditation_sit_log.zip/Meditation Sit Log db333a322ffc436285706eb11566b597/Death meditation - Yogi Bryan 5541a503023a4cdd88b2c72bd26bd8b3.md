# Death meditation - Yogi Bryan

Date & Time ⏰: October 17, 2022 11:22 AM
Guided: Yes
Length (Minutes): 38
Tags: Death

# Practice

# Content

- triggered when picturing funeral
- Triggered more when picturing myself on my death bed

# Focus / Action Step

- Live an amazing life