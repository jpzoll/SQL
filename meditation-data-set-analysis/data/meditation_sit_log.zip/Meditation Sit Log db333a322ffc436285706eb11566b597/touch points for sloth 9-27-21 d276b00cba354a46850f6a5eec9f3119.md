# touch points for sloth 9-27-21

Date & Time ⏰: September 27, 2021 8:52 AM

- Belly breathing
- Not controlling the breath and doing body scanning from the bottom up (toes → head)
- Body scanning energized the body just enough so that sleepiness went away

# Focus

- Bodily awareness and not getting lost within thinking
- What meditation object?
    - Body
- Mindfulness in daily life
    - Bus
    - Working
        - Creative expression within presence
    - After class