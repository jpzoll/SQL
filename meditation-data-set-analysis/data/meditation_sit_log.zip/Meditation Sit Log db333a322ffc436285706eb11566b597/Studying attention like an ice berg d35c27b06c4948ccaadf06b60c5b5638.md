# Studying attention like an ice berg

Date & Time ⏰: November 10, 2022 1:01 PM
Guided: Yes
Length (Minutes): 20
Tags: Thoughts / Attention Wandering