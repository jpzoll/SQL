# Metta Return 4/7

Date & Time ⏰: October 7, 2022 2:50 PM
Length (Minutes): 33
Tags: Body / Grounding Awareness, Metta

# Practice

# Content

- wishing well for all without anything needed in return
- Wishing peace, happiness for people individually, the whole world
- Relaxing into practice
- Grounding awareness in beginning
- Welling up with Love in the heart
- The beauty of freedom from sufferiny
- Little bit of weak concentration in beginning, but rested into it when wandering when noticed

# Focus / Action Step

- metta again
- Ground in daily life
- How does selflessness and metta rise in daily life? With others? With myself?