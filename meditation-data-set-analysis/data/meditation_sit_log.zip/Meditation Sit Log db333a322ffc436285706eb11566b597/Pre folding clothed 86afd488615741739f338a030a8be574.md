# Pre folding clothed

Date & Time ⏰: September 16, 2022 11:41 AM
Length (Minutes): 17
Tags: Mindfulness of Breathing

# Practice

# Content

- shit concentration
- Dullness
- The mind must be all in on the breath inlclining towards its pleasure. Keep plugging away, realIzing effortless resting of attention on the breathing AND SHARP concentration like a sword
- Easy presence in conversation

# Focus / Action Step

- mindfulness of breathing
- Or a bottleneck preventing it