# Thinking in bunches

Date & Time ⏰: October 25, 2022 11:05 AM
Length (Minutes): 38
Tags: Thoughts / Attention Wandering

# Practice

# Content

- LOTS OF MIND WANDERING. More than usual
- Thought content 95% about the future
- MO was viscerally not strong
- Much is still being understood regarding thought and why the mind thinks it’s worthwhile to go out
- Wandering is to be worked on

# Focus / Action Step

- thought but with strong MO and intention
- Mindfulness of winding down for beD
    -