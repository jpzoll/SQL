# Midl : attention move 2

Date & Time ⏰: November 6, 2022 12:38 PM
Guided: Yes
Length (Minutes): 32
Tags: Thoughts / Attention Wandering

# Practice

- MIDL 20/52

# Content

- attention moved a lot, and it took until the end of the sit to slightly begin to notice the moment it wandered
- Lots of feelings and thoughts towards someone where there is resentment. I gave myself a moment to feel and brought strong intention back
- WEAKEST LINKS
    - attention wandering
    - Mind wandering
    - Forgetting
- 

# Focus / Action Step

- train this!!!! Keep doing it! I truly believe I am transmuting this new way of living life, of residing in the deepest of presence