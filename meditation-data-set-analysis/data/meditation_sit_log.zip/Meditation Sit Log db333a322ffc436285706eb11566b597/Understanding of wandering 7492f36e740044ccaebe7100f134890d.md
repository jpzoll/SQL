# Understanding of wandering

Date & Time ⏰: October 26, 2022 12:08 PM
Length (Minutes): 25
Tags: Thoughts / Attention Wandering

# Practice

# Content

- what is it like?
- Ultra learning is transforming

# Focus / Action Step