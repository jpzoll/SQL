# Sharpening the blade

Date & Time ⏰: September 19, 2022 11:01 AM
Length (Minutes): 55
Tags: Mindfulness of Breathing

# Practice

# Content

- good pockets of pure concentration on breathing
- Seeing through infinite continuous attention resting on breathing
- Seeing breakdowns and what they lead to
- Seeing the pain and pull of going out to wander
- Seeing the effects and consequences of wandering
- Gathering the whole mind to rest on breath, while delicately balancing effort (under, over, and optimal)
- At end, seeing a following of the WHOLE BREATH COMPLETELY
- Seeing whole breath following partly comes from trained in stillness / doing nothing

# Focus / Action Step

- ENTIRE BREATH FOLLOWING every breath. 5 minutes following and the effects that has
- Mindfulness of breathing