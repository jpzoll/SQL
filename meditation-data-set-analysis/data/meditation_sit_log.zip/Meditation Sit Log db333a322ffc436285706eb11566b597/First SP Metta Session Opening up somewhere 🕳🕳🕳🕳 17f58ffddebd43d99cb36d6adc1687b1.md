# First SP Metta Session | Opening up... somewhere 🕳🕳🕳🕳

Date & Time ⏰: July 8, 2021 2:32 PM
Length (Minutes): 47
Tags: MIDL 03/52, MIDL Metta Loved One

- Metta instruction
- Not sure how else to put this, but there was an opening up of the anus as I relaxed further and cultivated metta
- Pressure at the forehead. Not sure if this means anything
- Cultivating a field of metta around me reminded of the Vermont trip. That field of love is protective and brings out love within others
- Love the "bad" things the mind does, just like you love yourself and the people you care about