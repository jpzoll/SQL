# Fingers touch is longer

Date & Time ⏰: January 15, 2022 5:20 PM

# Practice

- diaphragmatic breathing
- Fingers touching

# Content

- relaxed body
- Fingers touching
- Lots of thoughts, but they were okay simply because I remembered the experience of touching, not focusing on the sensations itself

# Focus / Action Step

- continuous remembering for 10 minutes
- Pay close attention to how I feel when scrolling