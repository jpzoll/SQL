# Stillness, like water

Date & Time ⏰: August 26, 2021 3:18 PM

- Important Difference today → no retraining of belly breathing (due to that being strong)
- Much like I’ve said in the past, I relaxed at the source by doing nothing. That includes doing nothing about doing (aka doing nothing about habitual movements of attention... letting them be)
- I’ve learned in the past day that I was making the mistake of trying to hard with stillness. This was apparent during the 6 hour retreat

 Focus

- Continue Dropping all effort with stillness
- Drop all effort with judging
- Drop all effort with intention-less, mindless movements of action
- Pay attention to Indulging in stimulation
- READDDDD