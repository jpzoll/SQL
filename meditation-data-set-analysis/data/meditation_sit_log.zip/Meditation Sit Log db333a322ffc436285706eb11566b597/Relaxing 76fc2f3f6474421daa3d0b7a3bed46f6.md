# Relaxing

Date & Time ⏰: January 5, 2023 8:28 AM
Guided: Yes
Length (Minutes): 15
Tags: Wim Hoff

# Practice

# Content

Better intention today

Seeing moment crossing into wandering

High blockage that naturally dissolved

No “better” or “more quality” of mindfulness, simply whatever mindfulness was present is enough

# Focus / Action Step

# Practice

# Content

# Focus / Action Step