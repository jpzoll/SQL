# Identification = dual elements

Date & Time ⏰: September 9, 2021 9:39 AM

- Identification→ JUST ONE element
- Don’t try for mechanics to one element, focus on the resulting feeling
    - Expansion and coolness feeling of our breath instead of the “proper” mechanics of a softening breath
- Elements change when in and out of delusion/forgetting
- Focusing cool feeling of out breath, even when weak, was gratifying

Focus

- Some forgetting
- Relax effort throughout today
- What is the next best thing to work on?