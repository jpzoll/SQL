# Sunday life contemplation

Date & Time ⏰: October 24, 2022 12:41 AM
Length (Minutes): 35
Tags: Contemplation

# Practice

# Content

- what do you value most in life?
- Get creative about locations. You’re choices are not as binary as NYC or cuse
    - Drop logic and rationality
- The heart of this is managing finances and providing massive value to the world through my work, which brings us back to the previous point

1. being an amazing leader that can handle all tense situations with ease
2. being a master of social skills that creates a great bubble of comradely and genuine relationships built upon honesty, integrity, and Love

Now, the action point is figuring out HOW TO OFFER THIS VALUE.

- YouTube channel
- 

# Focus / Action Step