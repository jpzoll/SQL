# Feeling the great rinsing of water

Date & Time ⏰: January 11, 2023 12:06 PM
Guided: Partially
Length (Minutes): 48
Tags: Ranged Awareness (MIDL 02/52)

# Practice

# Content

the remember the old suffering of being stuck within the confines of narrow attention that does not translate well to daily life. i remember the confusion of feeling immense peace in samadhi arising from unification of attention on the breath and then all the hindrances returning upon returning to daily life. this led to shielding, suppresion of emotions for some reason probably due to the fear of not understanding what was going on

i know now how beautiful it is to embrace what you are feeling. deeply feel pain, yearning, wanting, joy, sadness, fear, anger, all of those things. When needed explore them with journaling, but just ************************Trust yourself that you *********will know********* when it is the right time to journal, meditate, etc. Never worry, just stick to your intentions and the time will come to do what is necessary.**

### 

# Focus / Action Step