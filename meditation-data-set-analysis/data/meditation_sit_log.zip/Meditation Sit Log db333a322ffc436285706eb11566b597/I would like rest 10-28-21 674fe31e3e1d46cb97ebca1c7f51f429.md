# I would like rest 10-28-21

Date & Time ⏰: October 28, 2021 1:43 PM

# Practice

- Diaphragmatic breathing
- Samatha on the body and then breath

# Content

- Slightly more mindfulness than yesterday
- Diligence on the breath and taking the leap of faith to do so
- Grateful every time I remembered

# Focus / Action Step

- Conscious awareness of partying
- Android programming but then rest
- Notice urge to keep working numbers up