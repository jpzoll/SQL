# vermont don't lie! 10-9-21

Date & Time ⏰: October 9, 2021 2:10 PM

# Practice

- Grounding awareness
- Metta

# Content

- Strengthening remembering
    - One of the most heedful I've been during the later parts of my sits
    - Remembering *while doing **metta***
- Things felt dry and easy for fear to rise up within, and at that moment metta came up naturally and I went with it
- Body was not clear as I tapped into the sensations

# Focus / Action Step

- Metta
    - Make this the heart of my sits for next few days
    - "Can I generate a feeling of love?"
    - Set the intention to *remember* while doing metta, just as if it is the breath or body