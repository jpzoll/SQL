# calmed source / calming anxiety about anxiety

Date & Time ⏰: July 15, 2021 1:32 PM

- Became aware of the “worrier about the worrier”
    - “Am I doing stillness right? Can I maintain this?” Etc
    - Seeing it felt like seeing the “source”. However, realizing that there something ELSE/awareness on top of THAT awareness of awareness felt like a strange recursive loop that I’ve only experienced on psychedelics
    - The “guilter” that loves guilting when the realization that I have been mind wandering/forgetting occurs

- I am choosing to be grateful for what I feel right now, but understanding that it is impermanent
- 

# Focus

- Continue stillness
- Be Aware if dullness
- Weakness: Mindfulness and forgetting