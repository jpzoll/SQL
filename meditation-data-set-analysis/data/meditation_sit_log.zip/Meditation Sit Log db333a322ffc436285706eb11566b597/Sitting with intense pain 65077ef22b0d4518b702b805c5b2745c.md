# Sitting with intense pain

Date & Time ⏰: July 10, 2021 4:53 PM

- Metta was glowing
- Stillness
    - Relaxed into it
    - Few periods of “doing”
    - Few periods of “trying to maintain” stillness → notice and soften relationship to that trying
    - Strong emotions bubbled up and felt at the face mostly. this happened about 2-3 times (where the magnitude of feeling) was high
    - There was a point where this happened and lots of “relief” was felt in the body in mind, as if unconscious material was being “cleaned out”. I softened the effort to “maintain” this and it permeated throughout the face and throat region