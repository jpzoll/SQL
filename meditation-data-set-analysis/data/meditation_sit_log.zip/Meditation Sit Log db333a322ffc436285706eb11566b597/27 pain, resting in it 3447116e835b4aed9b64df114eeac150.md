# 27 pain, resting in it

Date & Time ⏰: January 6, 2023 6:59 PM
Length (Minutes): 27