# We are groot - volume 3

Date & Time ⏰: December 4, 2022 3:17 AM
Guided: Yes
Length (Minutes): 25
Tags: Wim Hoff

# Practice

# Content

- be with the unhappiness, utterly okay to be unhappy.
- Contemplative fitness is real work like the gym

# Focus / Action Step