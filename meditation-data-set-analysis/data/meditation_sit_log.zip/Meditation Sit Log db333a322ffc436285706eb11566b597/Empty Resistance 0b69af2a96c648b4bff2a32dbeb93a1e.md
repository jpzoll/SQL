# Empty Resistance

Date & Time ⏰: October 13, 2022 11:32 AM
Length (Minutes): 45
Tags: Contemplation, Shadow / Trauma

# Practice

> what am I resisting?
> 

# Content

- nothing strong came up in awareness
- Most of the sit was accompanied with relaxations of the mind stillness. Not doing anything other than sitting. When the mind was seen to be wandering, that was relaxed

# Focus / Action Step

- same question again or stillness practice