# Dayuuuum

Date & Time ⏰: January 12, 2023 1:10 PM
Length (Minutes): 39

# Practice

# Content

- No samadhi but diligent returning to breath
- Raw intention that can be helped with something like reading TMI
- Moderate satisfaction from returning that I can see is a condition for unification of attention

# Focus / Action Step

- keep returning so the mind keeps remembering how much better it is to rest with the breath and then it is effortless
- Mindfulness of breathing