# Delicious stillness in bird 11-17-21

Date & Time ⏰: November 17, 2021 1:45 PM

# Practice

- Shamatha w body and then breath

# Content

- Grateful for each instance of remembering
- Didn’t make it to breath, but got good concentration practice with body
- Satisfying stillness

# Focus / Action Step

Notes

- Allow practice to break down and build up again for enhanced clarity each “round” of experience
- The most fruitful meditations are those with a  self -induced intention (beginning and end with clear plan)
- Observer the consequences per planned episode and learn
- Use LoA to visualizes mastery/success/progresssion