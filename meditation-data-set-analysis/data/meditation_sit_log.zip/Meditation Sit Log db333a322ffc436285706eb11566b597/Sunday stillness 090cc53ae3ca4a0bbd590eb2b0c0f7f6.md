# Sunday stillness

Date & Time ⏰: October 16, 2022 2:54 PM
Length (Minutes): 33
Tags: Stillness

# Practice

# Content

- dullness
- Wandering
- Resting in the frame

# Focus / Action Step

- what is the source of thinking that arises in stillness? Is it possible for it to cease completely? What does that look like?
- Stillness again maybe midl long