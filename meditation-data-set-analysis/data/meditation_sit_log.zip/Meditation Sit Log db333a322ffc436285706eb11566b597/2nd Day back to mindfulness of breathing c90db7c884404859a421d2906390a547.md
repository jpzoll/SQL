# 2nd Day back to mindfulness of breathing

Date & Time ⏰: July 29, 2021 1:43 PM
Length (Minutes): 43
Tags: MIDL 06/52, Mindfulness of Breathing, Standing Meditation

# What happened?

Three Physical Postures

- Laying down (5-10 minutes)
- Sitting (30 minutes)
- Standing up

Weaknesses?

- Lots of mind wandering
- Hard to distinct points, *if there were any*, where there was habitual control of the breath

# Focus

- Get sleep
- Follow guided meditation again tomorrow
- Be aware. Reside within whatever is present. Even control itself
- Mindfulness in daily life
- Root of weaknesses
    - Less clinging to working
    - Mindfulness while working
    -