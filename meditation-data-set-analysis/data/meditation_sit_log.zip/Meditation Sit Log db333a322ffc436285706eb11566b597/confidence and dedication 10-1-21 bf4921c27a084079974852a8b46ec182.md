# confidence and dedication 10-1-21

Date & Time ⏰: October 1, 2021 1:11 PM

I am dedicated to being free of worry, anxiety, guilt and I just proved that. I sat for 55 minutes with strong intention and a poise rooted in confidence. I am going to experiment. I am going to see what works and what doesn't work. No matter what I am going to figure this out. THe power of positive thought and love is amazing and I'm never going to give up on it.

# Focus

- So now I can choose either
    - Meditate on thoughts
    - Stillness
    - Metta
- Try out MIDL perception of thoughts. I haven't done it yet so

[MIDL Meditation Instruction: Observing Your Attention Move 1](https://www.youtube.com/watch?v=DMxuR8Cm_ws)