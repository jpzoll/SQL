# Pieces of the puzzle

Date & Time ⏰: January 24, 2023 1:47 PM
Length (Minutes): 16
Tags: Contemplation

# Practice

# Content

Seeing thoughts as mo

- fear of not getting a goodbye
- Seeing me travel the world making money for myself
- 

# Focus / Action Step

contemplate more

Allow direct truth arise, my deepest values arising as I do what is best for me with full confidence