# High energy

Date & Time ⏰: September 22, 2022 11:48 AM
Length (Minutes): 26
Tags: Stillness

# Practice

# Content

- body shaking from caffeine
- Seeing the moment mindfulness returns and staying still in the “precious moment” of the mind going out towards mental objects. It feels a bit painful, underneath the alluring craving
- Small Moments of stillness. What does it look like for the mind to completely rest? How does “going out” cease?

# Focus / Action Step

- Stillness again. Relax the body and mind, having it naturally incline towards no though