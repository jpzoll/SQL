# Dullness and moderate pain 11/11/21

Date & Time ⏰: November 11, 2021 2:57 PM

# Practice

- Grounding awareness within the body
- Samatha w the body

# Content

- Dullness and sleepiness from the very beginning
- Tuning up awareness
- Allowing pain + curiosity
- Watching the mind dish out thoughts and visualizations as distraction
- Continued streams of remembering

# Focus / Action Step

- What do I do between the meditation object and the mind going crazy? What is the balance? Samatha v Vipassana?
- Remember at points
    - Car
    - AI
    - Bus
- Visualize myself breathing peacefully with excellent posture