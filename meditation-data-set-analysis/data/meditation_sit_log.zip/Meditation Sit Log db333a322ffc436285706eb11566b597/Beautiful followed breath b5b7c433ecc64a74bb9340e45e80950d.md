# Beautiful followed breath

Date & Time ⏰: December 20, 2022 7:21 PM
Length (Minutes): 64
Tags: Body / Grounding Awareness, Thoughts / Attention Wandering

# Practice

# Content

The one thing is the breath, the relaxing effortless breath

Whole body isn’t a great meditation object

The breath is a great meditation object

Let go of counting

Next time, choose meditation object that is stuck with

See how mind rests with it, dropping all else

- wandering

Attention wanders, and tightens (in the head) in DIFFERENT DIRECTIONS

# Focus / Action Step

- mindfulness of breathing, allowing to attend to mind wandering dimension. See how it arises (drops) and how it passes away (rising back)