# Sitting With Pain

Date & Time ⏰: July 7, 2021 3:58 PM
Length (Minutes): 51
Tags: Doing Nothing, Stillness

- Breathing in the belly feels automatic even though I haven't focused on it for the past few days
- Sat with pain
- Body awareness, not thinking
    - That mode... be grateful for it
- There is no "answer" or "endgame" to the pain. That feels like the typical ego yearning for a future experience that will be fleeting. I will continue to investigate pain since this comes up as I do long (over 45 minute) sits