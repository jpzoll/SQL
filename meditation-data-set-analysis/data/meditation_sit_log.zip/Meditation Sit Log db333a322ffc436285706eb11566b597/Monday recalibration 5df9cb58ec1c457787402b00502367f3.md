# Monday recalibration

Date & Time ⏰: September 12, 2022 11:31 AM
Length (Minutes): 20
Tags: Body / Grounding Awareness, Mindfulness of Breathing

# Practice

- body
- Breath wide

# Content

- resting of mind

# Focus / Action Step

- body breath in class
- Body breath walking
- Slow movements
- Body breath cold approach

Next sit

- following whole breath for 10+ minutes