# What are the feelings surrounding sex?

Date & Time ⏰: September 10, 2022 12:54 PM
Length (Minutes): 37
Tags: Contemplation, Sex, Shadow / Trauma

# Practice

# Content

- visions of sexual success
- Sinking into resistance surrounding being seen
- Mantras - it is deeply and fundamentally okay to flirt and have sex with women

# Focus / Action Step

1. Read and study a book
2. Approach