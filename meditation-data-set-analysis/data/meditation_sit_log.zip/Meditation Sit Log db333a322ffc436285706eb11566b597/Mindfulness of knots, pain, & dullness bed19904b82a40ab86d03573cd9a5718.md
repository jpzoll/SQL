# Mindfulness of knots, pain, & dullness

Date & Time ⏰: August 19, 2022 12:15 PM
Length (Minutes): 30

# Practice

- mindfulness of contact
- Mindfulness of tension in body
    - Throat
- Mindfulness of pain

# Content

- high aversion to this issue that has come up so many times, and which I see with confidence is being transmuted with clean breathing that relaxes the tensiin
- High dullness with eyes closed, VERY dry
- LOTS of thinking, wandering. Worrying about LoA mechanics
- Kind words to self that inspire confidence and faith

# Focus / Action Step

- Fix the breathing. It must be done
- I am discovering what is creating this block and allowing it to fade away permanently