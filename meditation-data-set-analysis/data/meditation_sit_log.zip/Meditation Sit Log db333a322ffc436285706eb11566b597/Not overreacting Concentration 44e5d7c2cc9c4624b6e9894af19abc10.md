# Not overreacting > Concentration

Date & Time ⏰: August 13, 2021 3:47 PM

- Retraining breathing (going well!)
- Concentration
    - Laying down
    - sitting up
    - standing
    - Laying down again
    

# focus

- Get at least 8.5 hours of sleep in order to not fall asleep
- Sleep clinic
- Focus on when attention slips to focusing on posture or something else