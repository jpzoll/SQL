# before and after, find middle

Date & Time ⏰: November 7, 2022 11:18 AM
Guided: Yes
Length (Minutes): 30
Tags: Thoughts / Attention Wandering