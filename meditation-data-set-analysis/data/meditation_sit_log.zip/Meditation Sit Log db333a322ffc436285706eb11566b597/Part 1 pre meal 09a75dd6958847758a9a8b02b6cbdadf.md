# Part 1 pre meal

Date & Time ⏰: January 30, 2023 10:13 AM
Length (Minutes): 12
Tags: Mindfulness of Breathing

# Practice

# Content

- fuzziness
- Lack of clear remembering
- Thinking

# Focus / Action Step

- longer meditation
- Strong intention