# Contemplating 2 decision

Date & Time ⏰: January 27, 2023 3:55 PM
Length (Minutes): 65
Tags: Body / Grounding Awareness, Contemplation

# Practice

# Content

- the big bottleneck in this decision is the fear of me being stuck under the financial trap of my mother. I value being an independent and self-sufficient adult so I have the freedom to do the things I want to do
- The one way to combat this bottleneck is via starting my own business as a student and making good money. From here I can put money into my emergency fund, make projects, etc.
- the thing is though, I know my mother is intelligent, strong, smart, and a great supportive mother. I have to trust her that she can pay for this education
- Another bottleneck is classes. The key here is deep presence with the work, knowing the long term vision of learning the material is worthwhile, and

# Focus / Action Step