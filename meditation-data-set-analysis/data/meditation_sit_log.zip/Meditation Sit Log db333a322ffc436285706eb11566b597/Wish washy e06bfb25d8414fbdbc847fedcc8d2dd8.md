# Wish washy

Date & Time ⏰: January 19, 2023 1:34 PM
Length (Minutes): 26
Tags: Body / Grounding Awareness, Stillness

# Practice

# Content

- no clear grounding point or object

# Focus / Action Step

CLEAR INTENTION, CLAIRTY OF WHAT MINF TETURNS TO

contemplate more