# Short retraining and MIDL forgiveness

Date & Time ⏰: June 29, 2021 3:02 PM
Length (Minutes): 42
Tags: MIDL 03/52

What happened?

- Retrained breathing for about 12 minutes
- The less I forced it, the easier it was

What was weak?

- It felt hard to express love toward someone as if they were standing right in front of me. This was super awesome to realize because I've had this agreement that metta is fun and enjoyable. It felt like I was flexing that vulnerability muscle
- I attempted to practice with a very painful memory and it was a little difficult
- Came into the meditation was a small sense of doing. Remember that there is no goal, no place to go. Only being