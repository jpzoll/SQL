# Sleepy Bliss

Date & Time ⏰: August 9, 2021 11:29 AM
Tags: MIDL 03/52, Mindfulness of Breathing, Standing Meditation

# What happened?

- Retraining belly breathing
    - Very sleepy, but got the job done
- Mindfulness of breathing while sitting in chair
    - Very little control
    - Very enjoyable
    - Short sit (~10 minutes)

# Focus

- Do the same exact thing for my next sit
    - Intention: Rest Attention on the ***sensations*** of the breath (breath is the saw, tip of the nose eraser point is the table)
    - Continue this firm attention while noticing any excessive force that may be being applied