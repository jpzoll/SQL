# Back home, before the storm

Date & Time ⏰: August 21, 2021 11:43 PM

- As I expected, attention is a little scattered after a long week with lots of events
- I intend on training grounding in awareness for the next 1-3 days
- I intend on sitting longer in preparation for my retreat. I also intend on deciding when I will do the retreat
- Bodily awareness as opposed to thinking has become so much more distinct over the past few weeks/months. I am grateful for it
-