# still again

Date & Time ⏰: October 14, 2022 1:06 PM
Guided: Guided
Length (Minutes): 17
Tags: Stillness

# Practice

# Content

17 minutes of MIDL 02/20: Allowing Stillness

- relaxing each individual part of the body
- Experiencing the still mind, with occasional wanderings
- Relaxation very satisfying

# Focus / Action Step

- stillness again but longer