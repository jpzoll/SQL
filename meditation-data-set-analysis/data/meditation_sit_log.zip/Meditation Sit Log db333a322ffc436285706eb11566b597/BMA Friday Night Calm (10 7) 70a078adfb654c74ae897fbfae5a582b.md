# BMA Friday Night Calm (10/7)

Date & Time ⏰: October 8, 2022 4:20 PM
Length (Minutes): 30
Tags: Contemplation