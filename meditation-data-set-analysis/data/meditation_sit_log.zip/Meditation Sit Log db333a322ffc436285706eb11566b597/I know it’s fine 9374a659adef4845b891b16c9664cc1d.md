# I know it’s fine

Date & Time ⏰: December 24, 2022 11:03 AM
Guided: Yes
Length (Minutes): 15
Tags: Wim Hoff