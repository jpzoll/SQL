# The Bravest Meditation Of My Life

Date & Time ⏰: June 29, 2021 3:04 PM
Length (Minutes): 65
Tags: MIDL 03/52, MIDL Forgiveness

What did I just do?

- MIDL 03/52
- MIDL forgiveness

How long?

- 1 hour and 5 minutes

# What happened?

Today was my third day of doing MIDL Forgiveness, and I would like to share how my sit went today. I retrained belly breathing for about 10-20 minutes, then I moved onto forgiveness:

- Receiving and giving forgiveness to myself
- Receiving and giving forgiveness to family member #1
- Receiving and giving forgiveness to family member #2

After these three were done, I thought about doing forgiveness for someone else I may have hurt in the past. A great amount of fear arose, and I wondered if it was a good idea to even go down this route. I decided that I am confident in my abilities to handle whatever comes up.

I asked for forgiveness 3 times, just like in the training and there was a decent amount of resistance. There were some thoughts of guilt, negative vedana, etc. but I observed them from awareness. I imagined this person forgiving me and in a state of happiness.

Afterward, I went back to forgiving myself, and I realized this was more necessary than anything. The heart opened up as I imagined a happy, calm version of myself forgive 'me'. I imagined us embracing in a hug.

This was my third training of MIDL forgiveness this week, and each time it has given rise to an extreme amount of vulnerability.

It feels *weirdly* freeing. Of course, there is some emotional exhaustion after going through this, but I feel brave for pushing through the adversity and not hiding away. Hard work pays off