# Tough time with the breath

Date & Time ⏰: August 3, 2021 1:15 PM
Tags: MIDL 03/52, MIDL 06/52, Mindfulness of Breathing

# What happened?

- Difficulty breathing
- Constant thinking about the breathing and "getting it right"

# Focus

- Soften and drop all effort to make the breath a certain way
- Prepare next sit with some belly breathing to check if that was the root of the issue